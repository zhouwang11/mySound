package com.zhou.note;

public interface OnBPMChangedListener {
    void OnBPMChanged(int old,int come);
}
