package com.zhou.note;

public interface OnMajorChangedListener {
    void onMajorChange(MyNote.Major old, MyNote.Major come);
}
