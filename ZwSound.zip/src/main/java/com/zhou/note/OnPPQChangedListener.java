package com.zhou.note;

public interface OnPPQChangedListener {
    void onPPQChanged(String old,String come);
}
