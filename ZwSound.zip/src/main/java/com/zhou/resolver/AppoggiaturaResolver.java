package com.zhou.resolver;


import com.zhou.note.MyNoteIMPL;
import com.zhou.note.NoteInfo;

/**
 * 处理倚音倚音接口定义
 */
public interface AppoggiaturaResolver {
    NoteInfo[] appoggiatura(String noteFrontString, String noteAfterString, int noteStart, MyNoteIMPL myNoteIMPL, SingleNoteResolver singleNoteResolver);
}
