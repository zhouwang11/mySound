package com.zhou.resolver;


import com.zhou.note.MyNoteIMPL;
import com.zhou.note.NoteInfo;

/**
 * 单个音符解析接口定义
 */
public interface SingleNoteResolver {
    NoteInfo singleNoteResolve(MyNoteIMPL myNoteIMPL, String noteString, int originTick);
}
